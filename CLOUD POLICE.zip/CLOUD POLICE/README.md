# Online-Crime-Management-System (new)
This Online Crime Management Project has been done by Manash Jyoti Baruah.

What's New: Minor Bug Fix & Compatible with php7

Online crime management system can be use in real life scenario where any police station can use for online FIR taking and online case diary or overall whole case completion. Also any user can file FIR to nearest Police station and can get FIR status and after that case status respectively.

#Some of the system scrennshot is given below:

#(Also many more screenshots available but for sake of the demo i uploaded only some of it .)


![ocms1](https://user-images.githubusercontent.com/51418862/108726766-d2881f80-754d-11eb-8049-f8233224e391.png)
![ocms2](https://user-images.githubusercontent.com/51418862/108726770-d3b94c80-754d-11eb-8a04-cd43c5c4aca3.png)
![ocms3](https://user-images.githubusercontent.com/51418862/108726776-d4ea7980-754d-11eb-9dff-4782c1634dee.png)
![ocms4](https://user-images.githubusercontent.com/51418862/108726783-d61ba680-754d-11eb-89dc-38d905d78d68.png)
![ocms5](https://user-images.githubusercontent.com/51418862/108726788-d74cd380-754d-11eb-8773-415e019fea2d.png)
![ocms6](https://user-images.githubusercontent.com/51418862/108726790-d7e56a00-754d-11eb-8ddf-a6851449329d.png)
![ocms7](https://user-images.githubusercontent.com/51418862/108726799-d9169700-754d-11eb-985b-4ed49eec5e98.png)
![ocms8](https://user-images.githubusercontent.com/51418862/108726805-d9af2d80-754d-11eb-947b-bab1c0bd0aa2.png)
![o9](https://user-images.githubusercontent.com/51418862/108726814-db78f100-754d-11eb-9b0d-59325a2f294f.png)
![o10](https://user-images.githubusercontent.com/51418862/108726816-dc118780-754d-11eb-8c3c-7cd491cfc803.png)
![o11](https://user-images.githubusercontent.com/51418862/108726820-dcaa1e00-754d-11eb-9a87-01c82c5c7120.png)
![o12](https://user-images.githubusercontent.com/51418862/108726826-dddb4b00-754d-11eb-9e26-03d282e8a3ec.png)
![o13](https://user-images.githubusercontent.com/51418862/108726831-de73e180-754d-11eb-9d0e-d5a7938e1ff5.png)
![o14](https://user-images.githubusercontent.com/51418862/108726834-df0c7800-754d-11eb-8e8e-c7358ee4ca8f.png)
![o15](https://user-images.githubusercontent.com/51418862/108726838-e03da500-754d-11eb-81da-4cfdace9deaf.png)
![o16](https://user-images.githubusercontent.com/51418862/108726841-e0d63b80-754d-11eb-9a50-8515f3ee05e0.png)

















